package com.petsystem.pet_project.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // "uploads" klasörünü dışarıya "/photos/" adresiyle açar
        registry.addResourceHandler("/photos/**")
                .addResourceLocations("file:uploads/");
    }
}