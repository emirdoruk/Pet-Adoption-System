const API_URL = "http://localhost:8080/api";
const userEmail = localStorage.getItem("userEmail");
const userRole = localStorage.getItem("userRole");

/* --- SAYFA YÜKLENDİĞİNDE ÇALIŞACAK MANTIK --- */
document.addEventListener("DOMContentLoaded", () => {
    // 1. Hangi sayfadayız?
    const path = window.location.pathname;

    if (path.includes("login.html")) {
        // LOGIN SAYFASI
        setupLoginRegister();
    } 
    else if (path.includes("owner.html")) {
        // PET OWNER SAYFASI
        if (!userEmail || userRole !== "PET_OWNER") { window.location.href = "login.html"; return; }
        setupOwnerDashboard();
    } 
    else if (path.includes("vet.html")) {
        // VET SAYFASI
        if (!userEmail || userRole !== "VET") { window.location.href = "login.html"; return; }
        setupVetDashboard();
    }
});

/* =========================================
   1. LOGIN & REGISTER İŞLEMLERİ
   ========================================= */
function setupLoginRegister() {
    // Giriş Yap
    const loginForm = document.querySelector("#login-form form"); // form etiketini seç
    if (loginForm) {
        loginForm.onsubmit = async (e) => {
            e.preventDefault();
            const email = document.getElementById("login-email").value;
            const pass = document.getElementById("login-pass").value;

            try {
                const res = await fetch(`${API_URL}/users/login?email=${email}&password=${pass}`, { method: "POST" });
                if (res.ok) {
                    const user = await res.json();
                    localStorage.setItem("userEmail", user.email);
                    localStorage.setItem("userName", user.name);
                    localStorage.setItem("userRole", user.role);

                    // Rolüne göre yönlendir
                    if (user.role === "VET") window.location.href = "vet.html";
                    else window.location.href = "owner.html";
                } else {
                    alert("Giriş başarısız! Bilgileri kontrol et.");
                }
            } catch (err) { console.error(err); alert("Sunucu hatası!"); }
        };
    }

    // Kayıt Ol
    const regForm = document.querySelector("#register-form form");
    if (regForm) {
        regForm.onsubmit = async (e) => {
            e.preventDefault();
            const data = {
                name: document.getElementById("reg-name").value,
                email: document.getElementById("reg-email").value,
                password: document.getElementById("reg-pass").value
            };
            const role = document.getElementById("reg-role").value;
            
            // Vet mail kontrolü
            if (role === "vet" && !data.email.endsWith("@vet.com")) {
                alert("Veteriner maili @vet.com ile bitmeli!");
                return;
            }

            try {
                const res = await fetch(`${API_URL}/users/register`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(data)
                });
                if (res.ok) {
                    alert("Kayıt Başarılı! Giriş yapabilirsin.");
                    toggleForms();
                } else {
                    alert("Kayıt hatası (Mail kullanılıyor olabilir).");
                }
            } catch (err) { console.error(err); }
        };
    }
}

function toggleForms() {
    document.getElementById("login-form").classList.toggle("hidden");
    document.getElementById("register-form").classList.toggle("hidden");
}


/* =========================================
   2. PET OWNER DASHBOARD İŞLEMLERİ
   ========================================= */
function setupOwnerDashboard() {
    // Kullanıcı adını yaz
    document.getElementById("user-name").innerText = localStorage.getItem("userName");
    
    // Varsayılan açılış
    navOwner('dashboard');
}

// Owner Menü Geçişleri
function navOwner(viewId) {
    // Hepsini gizle
    document.querySelectorAll('[id^="view-"]').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));

    // İsteneni aç
    const view = document.getElementById('view-' + viewId);
    const link = document.getElementById('link-' + viewId);
    if (view) view.classList.remove('hidden');
    if (link) link.classList.add('active');

    // Verileri yükle
    if (viewId === 'dashboard') loadOwnerStats();
    if (viewId === 'my-pets') loadMyPets();
    if (viewId === 'all-pets') loadAllPetsForAdoption();
    if (viewId === 'requests') loadRequests();
}

async function loadOwnerStats() {
    // İstatistikler için basitçe listeleri çekip sayısını alıyoruz
    const res = await fetch(`${API_URL}/pets/my?mail=${userEmail}`);
    const pets = await res.json();
    document.getElementById("stat-pets").innerText = pets.length;
    
    const reqRes = await fetch(`${API_URL}/adoptions/received?mail=${userEmail}`);
    const reqs = await reqRes.json();
    const pending = reqs.filter(r => r.status === 'PENDING');
    document.getElementById("stat-req").innerText = pending.length;
}

async function loadMyPets() {
    const res = await fetch(`${API_URL}/pets/my?mail=${userEmail}`);
    const pets = await res.json();
    const container = document.getElementById("my-pets-list");
    container.innerHTML = "";

    if (pets.length === 0) container.innerHTML = "<p>Henüz evcil hayvanın yok.</p>";

    pets.forEach(p => {
        const img = p.image ? `http://localhost:8080${p.image}` : 'https://via.placeholder.com/300?text=No+Image';
        container.innerHTML += `
        <div class="pet-card">
            <img src="${img}" class="pet-img">
            <div class="pet-body">
                <h4>${p.name}</h4>
                <p class="text-muted">${p.species} • ${p.age} yaş</p>
                <button class="btn" style="color:red; border:1px solid #eee; margin-top:10px; width:100%;" onclick="deletePet(${p.id})">Sil</button>
            </div>
        </div>`;
    });
}

async function loadAllPetsForAdoption() {
    const res = await fetch(`${API_URL}/pets/available`);
    const pets = await res.json();
    const container = document.getElementById("all-pets-list");
    container.innerHTML = "";

    pets.forEach(p => {
        // Sadece başkalarının hayvanlarını göster
        if (p.owner && p.owner.email !== userEmail) {
            const img = p.image ? `http://localhost:8080${p.image}` : 'https://via.placeholder.com/300?text=No+Image';
            container.innerHTML += `
            <div class="pet-card">
                <img src="${img}" class="pet-img">
                <div class="pet-body">
                    <span class="badge badge-avail">SAHİPLENİLEBİLİR</span>
                    <h4>${p.name}</h4>
                    <p class="text-muted">${p.species} • Sahibi: ${p.owner.name}</p>
                    <button class="btn btn-orange" style="width:100%; margin-top:10px;" onclick="sendRequest(${p.id})">Sahiplenme İsteği At</button>
                </div>
            </div>`;
        }
    });
}

async function submitPet() {
    const form = document.querySelector("#view-add-pet form");
    const name = document.getElementById("p-name").value;
    const species = document.getElementById("p-species").value;
    const age = document.getElementById("p-age").value;
    const file = document.getElementById("p-file").files[0];

    const formData = new FormData();
    formData.append("name", name);
    formData.append("species", species);
    formData.append("age", age);
    formData.append("mail", userEmail);
    if (file) formData.append("image", file);

    try {
        const res = await fetch(`${API_URL}/pets`, { method: "POST", body: formData });
        if (res.ok) {
            alert("Hayvan eklendi!");
            form.reset();
            navOwner('my-pets');
        } else {
            alert("Hata oluştu.");
        }
    } catch (e) { console.error(e); }
}

async function deletePet(id) {
    if (!confirm("Silmek istediğine emin misin?")) return;
    await fetch(`${API_URL}/pets/${id}?mail=${userEmail}`, { method: "DELETE" });
    loadMyPets();
}

async function sendRequest(petId) {
    if (!confirm("Sahiplenme isteği gönderilsin mi?")) return;
    const res = await fetch(`${API_URL}/adoptions?petId=${petId}&mail=${userEmail}`, { method: "POST" });
    if (res.ok) { alert("İstek gönderildi!"); navOwner('requests'); }
    else alert("Hata oluştu.");
}

async function loadRequests() {
    // 1. Giden İstekler (Sent Requests) - Bildirim silme "X" eklendi
    const sentRes = await fetch(`${API_URL}/adoptions/sent?mail=${userEmail}`);
    const sent = await sentRes.json();
    const sentContainer = document.getElementById("sent-list");
    sentContainer.innerHTML = sent.length ? "" : "<p>Gönderilen istek yok.</p>";
    
    sent.forEach(r => {
        let color = r.status === 'APPROVED' ? 'green' : (r.status === 'REJECTED' ? 'red' : 'orange');
        sentContainer.innerHTML += `
        <div style="background:white; padding:15px; border:1px solid #eee; border-radius:8px; border-left: 5px solid ${color}; display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
            <div>
                <strong>${r.pet.name}</strong> için istek gönderildi. Durum: <b style="color:${color}">${r.status}</b>
            </div>
            <button onclick="dismissRequest(${r.id})" style="background:none; border:none; color:#888; cursor:pointer; font-size:20px; padding:0 10px; font-weight:bold;">&times;</button>
        </div>`;
    });

    // 2. Gelen İstekler (Incoming Requests) - Onayla/Reddet butonları düzenlendi
    const recRes = await fetch(`${API_URL}/adoptions/received?mail=${userEmail}`);
    const rec = await recRes.json();
    const recContainer = document.getElementById("received-list");
    recContainer.innerHTML = "";
    
    const pending = rec.filter(r => r.status === 'PENDING');
    if (pending.length === 0) recContainer.innerHTML = "<p>Bekleyen gelen istek yok.</p>";

    pending.forEach(r => {
        recContainer.innerHTML += `
        <div style="background:white; padding:15px; border:1px solid #eee; border-radius:8px; display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
            <div>
                <strong>${r.requester.name}</strong>, senin <strong>${r.pet.name}</strong> isimli hayvanını sahiplenmek istiyor.
            </div>
            <div style="display:flex; gap:10px;">
                <button class="btn btn-teal" onclick="processReq(${r.id}, 'approve')">Onayla</button>
                <button class="btn" style="border:1px solid #f44336; color:#f44336;" onclick="processReq(${r.id}, 'reject')">Reddet</button>
            </div>
        </div>`;
    });
}

async function processReq(id, action) {
    const userEmail = localStorage.getItem("userEmail");
    // action: 'approve' veya 'reject'
    const res = await fetch(`${API_URL}/adoptions/${id}/${action}?mail=${userEmail}`, { method: "POST" });
    if (res.ok) {
        alert(`İşlem başarıyla gerçekleşti: ${action}`);
        loadRequests(); // Listeyi yenile
    }
}
async function dismissRequest(id) {
    if (confirm("Bu bildirimi kalıcı olarak silmek istediğine emin misin?")) {
        // Backend'deki @DeleteMapping("/{id}") metodunu çağırır
        const res = await fetch(`${API_URL}/adoptions/${id}`, { method: "DELETE" });
        if (res.ok) {
            loadRequests(); // Listeyi anında yenile
        } else {
            alert("Silme işlemi başarısız oldu.");
        }
    }
}

/* =========================================
   3. VET DASHBOARD İŞLEMLERİ
   ========================================= */
let currentVetPetId = null;

function setupVetDashboard() {
    document.getElementById("user-name").innerText = localStorage.getItem("userName");
    navVet('dashboard');
}

function navVet(viewId) {
    document.querySelectorAll('[id^="view-"]').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));

    const view = document.getElementById('view-' + viewId);
    const link = document.getElementById('link-' + viewId);
    if (view) view.classList.remove('hidden');
    if (link) link.classList.add('active');

    if (viewId === 'dashboard') loadVetStats();
    if (viewId === 'view-pets') loadAllPetsForVet();
}

async function loadVetStats() {
    const res = await fetch(`${API_URL}/pets/available`);
    const pets = await res.json();
    document.getElementById("stat-pets").innerText = pets.length;
}

async function loadAllPetsForVet() {
    const res = await fetch(`${API_URL}/pets/available`);
    const pets = await res.json();
    const container = document.getElementById("pets-list");
    container.innerHTML = "";

    pets.forEach(p => {
        const img = p.image ? `http://localhost:8080${p.image}` : 'https://via.placeholder.com/300?text=No+Image';
        container.innerHTML += `
        <div class="pet-card">
            <img src="${img}" class="pet-img">
            <div class="pet-body">
                <h4>${p.name}</h4>
                <p class="text-muted">${p.species}</p>
                <button class="btn btn-teal" style="width:100%; margin-top:10px;" 
                   onclick="openVetDetail(${p.id}, '${p.name}', '${p.species}', '${p.image}', '${p.owner ? p.owner.name : 'Bilinmiyor'}')">
                   Detayları Gör
                </button>
            </div>
        </div>`;
    });
}

async function openVetDetail(id, name, species, image, owner) {
    currentVetPetId = id;
    
    // Detayları doldur
    document.getElementById("d-name").innerText = name;
    document.getElementById("d-info").innerText = species;
    document.getElementById("d-owner").innerText = "Sahibi: " + owner;
    
    const imgUrl = (image && image !== 'null') ? `http://localhost:8080${image}` : 'https://via.placeholder.com/300?text=No+Image';
    document.getElementById("d-img").src = imgUrl;

    // Sayfayı değiştir
    document.getElementById("view-view-pets").classList.add("hidden");
    document.getElementById("view-pet-detail").classList.remove("hidden");

    loadHealthRecords(id);
}

async function loadHealthRecords(petId) {
    const res = await fetch(`${API_URL}/pets/${petId}/health-records`);
    const records = await res.json();
    const container = document.getElementById("records-list");
    container.innerHTML = "";

    if (records.length === 0) container.innerHTML = "<p>Kayıt yok.</p>";

    records.forEach(r => {
        container.innerHTML += `
        <div style="background:white; padding:15px; border:1px solid #ddd; border-radius:8px;">
            <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                <h5 class="text-teal" style="font-weight:600;">${r.diagnosis || 'Tanı Yok'}</h5>
                <small>${r.date || ''}</small>
            </div>
            <p><strong>Tedavi:</strong> ${r.treatment || '-'}</p>
            <p class="text-muted">Not: ${r.notes || '-'}</p>
            <small style="color:#999; display:block; margin-top:5px;">Vet: ${r.vetName}</small>
        </div>`;
    });
}

function showAddForm() { document.getElementById("add-record-form").classList.remove("hidden"); }
function hideAddForm() { document.getElementById("add-record-form").classList.add("hidden"); }

async function submitRecord() {
    const description = document.getElementById("h-desc").value;

    if (!description.trim()) {
        alert("Lütfen bir açıklama girin.");
        return;
    }

    // KRİTİK: Backend formatına uygun URL (RequestParam kullanımı)
    const url = `${API_URL}/pets/${currentVetPetId}/health-records?description=${encodeURIComponent(description)}&mail=${userEmail}`;

    try {
        const res = await fetch(url, {
            method: "POST" // Body yok, headers{Content-Type} gerekmiyor çünkü parametreler URL'de
        });

        if (res.ok) {
            alert("Sağlık kaydı başarıyla eklendi!");
            document.getElementById("h-desc").value = ""; // Formu temizle
            hideAddForm();
            loadHealthRecords(currentVetPetId); // Listeyi yenileyerek bugünün tarihli kaydını gör
        } else {
            const errorText = await res.text();
            alert("Hata: " + errorText);
        }
    } catch (err) {
        console.error("Fetch hatası:", err);
        alert("Sunucuya bağlanılamadı.");
    }
}


/* --- ORTAK --- */
function logout() {
    localStorage.clear();
    window.location.href = "login.html";
}